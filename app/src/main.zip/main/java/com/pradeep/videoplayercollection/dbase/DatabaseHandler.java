package com.pradeep.videoplayercollection.dbase;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Parcel;
import android.util.Log;

import com.pradeep.videoplayercollection.CommonFile;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class DatabaseHandler {
    private static final String TAG = "UserDataBase";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "UserDataBase.db";
    private static final String TABLE_NAME = "user_table";

    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME +
            " (" + "Userid INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT," +
            "UserName TEXT UNIQUE NOT NULL,Password TEXT,Email TEXT,MAC TEXT,Question1 TEXT," +
            " Answer1 TEXT,Question2 TEXT,Answer2 TEXT,AdminPin INTEGER,Admin INTEGER DEFAULT 0);";

    private static final int kUserIdBase = 1001;
    private static final String DATA_BASE_LOCATION = "/data/data/com.pradeep.videoplayercollection/databases/UserDataBase.db";

    //Create userdata database
    private static final String USER_DATA_BASE_LOCATION = "/data/data/com.pradeep.videoplayercollection/databases/userdata.db";
    private static final String CREATE_FAVOURITE_TABLE = "CREATE TABLE Favourite ( CNumber INTEGER NOT NULL, CName TEXT NOT NULL ,PName TEXT DEFAULT NULL , UserID INTEGER NOT NULL);";
    private static final String CREATE_VERSION_TABLE = "CREATE TABLE version_state (version INTEGER NOT NULL, last_updated_on INTEGER, last_updated_time INTEGER," + " UserID INTEGER PRIMARY KEY);";
    private static final String CREATE_RECORD_TABLE = "CREATE TABLE Record_data (file TEXT NOT NULL UNIQUE, last_view_on INTEGER);";
    private static final String CREATE_REMINDER_TABLE = "CREATE TABLE Reminder (CNumber INTEGER NOT NULL ,channel_name TEXT,  program_name TEXT NOT NULL , date INTEGER , start_time INTEGER , end_time INTEGER, repeat INTEGER DEFAULT 0,UserID INTEGER NOT NULL);";
    private static final String NOTIFICATION_DATA_BASE_LOCATION = "/data/data/com.pradeep.videoplayercollection/notificationdata.db";
    private static final String CREATE_NOTIFICATION_TABLE = "CREATE TABLE PassiveNotification ( NotNumber INTEGER PRIMARY KEY AUTOINCREMENT , Notifications TEXT , notificationDate INTEGER , deleteDate INTEGER , etc1 TEXT , etc2 TEXT , etc3 TEXT , SessionID INTEGER NOT NULL , Status INTEGER DEFAULT 0);";
    private static final String CREATE_ACTIVITY_LOG_TABLE = "CREATE TABLE ActivityLog ( NotNumber INTEGER PRIMARY KEY AUTOINCREMENT , Notifications TEXT , notificationDate INTEGER , deleteDate INTEGER , etc1 TEXT , etc2 TEXT , etc3 TEXT , SessionID INTEGER NOT NULL , Status INTEGER DEFAULT 0);";

    DatabaseHandler(Context context) {
        SQLiteDatabase db;
        File mDataBase = new File(DATA_BASE_LOCATION);
        if (!mDataBase.exists()) {
            Log.v(TAG, "db1 db");
            db = new myDbHelper(context, DATA_BASE_LOCATION).getWritableDatabase();
            db.close();
            Log.v(TAG, "db1 db done");
        }
        File mUserDatabase = new File(USER_DATA_BASE_LOCATION);
        if (!mUserDatabase.exists()) {
            Log.v(TAG, "upgrade db2");
            db = new myDbHelper(context, USER_DATA_BASE_LOCATION).getWritableDatabase();
            db.close();
            Log.v(TAG, "upgrade db2 done");
        }

        File mNotificationDatabase = new File(NOTIFICATION_DATA_BASE_LOCATION);
        if (!mNotificationDatabase.exists()) {
            Log.v(TAG, "upgrade db3");
            db = new myDbHelper(context, NOTIFICATION_DATA_BASE_LOCATION).getWritableDatabase();
            db.close();
            Log.v(TAG, "upgrade db3 done");
        }
    }

    class myDbHelper extends SQLiteOpenHelper {
        private String database;

        public myDbHelper(Context context, String database) {
            super(context, database, null, DATABASE_VERSION);
            this.database = database;
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                if (database.equals(DATA_BASE_LOCATION)) {
                    Log.e(TAG, "upgrade d4 done");
                    db.execSQL(CREATE_TABLE);
                } else if (database.equals(USER_DATA_BASE_LOCATION)) {
                    db.execSQL(CREATE_FAVOURITE_TABLE);
                    db.execSQL(CREATE_VERSION_TABLE);
                    db.execSQL(CREATE_RECORD_TABLE);
                    db.execSQL(CREATE_REMINDER_TABLE);
                } else if (database.equals(NOTIFICATION_DATA_BASE_LOCATION)) {
                    db.execSQL(CREATE_NOTIFICATION_TABLE);
                    db.execSQL(CREATE_ACTIVITY_LOG_TABLE);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        protected void finalize() throws Throwable {
            this.close();
            super.finalize();
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.v(TAG, "upgrade db");
        }
    }

    public CommonFile.DB_Status fetchUserDataBase(int parameter, Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        if (parameter == CommonFile.kActionRegisterUser) {
            status = register_new_user(info);
        } else if (parameter == CommonFile.kActionSetAdmin) {
            status = set_admin(info);
        } else if (parameter == CommonFile.kActionSetAdminPin) {
            status = setAdminPin(info);
        } else if (parameter == CommonFile.kActionDeleteUser) {
            status = delete_user(info);
        } else if (parameter == CommonFile.kActionCheckAdmin) {
            status = check_admin(info);
        } else if (parameter == CommonFile.kActionVerfyUser) {
            status = verify_user(info);
        } else if (parameter == CommonFile.kActionChangeSecurity) {
            status = change_security(info);
        } else if (parameter == CommonFile.kActionGetSecurity) {
            status = get_security(info);
        } else if (parameter == CommonFile.kActionSetFavourite) {
            status = setFavourite(info);
        } else if (parameter == CommonFile.kActionRemoveFavourite) {
            status = removeFavourite(info);
        } else if (parameter == CommonFile.kActionFetchFavourite) {
            status = fetchFavourite(info);
        } else if (parameter == CommonFile.kActionCheckFavourite) {
            status = checkFavourite(info);
        } else if (parameter == CommonFile.kActionCheckUserDataVersion) {
            status = checkUserDataVersion(info);
        } else if (parameter == CommonFile.kActionSetReminder) {
            status = addReminder(info);
        } else if (parameter == CommonFile.kActionDeleteReminder) {
            status = removeReminder(info);
        } else if (parameter == CommonFile.kActionFetchReminder) {
            status = fetchReminder(info);
        } else if (parameter == CommonFile.kActionOccurredReminder) {
            status = getOccurredReminders(info);
        } else if (parameter == CommonFile.kActionUpdateRecordView) {
            status = updateRecordData(info);
        } else if (parameter == CommonFile.kActionCheckRecord) {
            status = checkRecordData(info);
        } else {
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status register_new_user(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor insertUserData = null;
        info.setDataPosition(0);
        String name = info.readString();
        String userName = info.readString();
        String password = info.readString();
        String email = info.readString();
        String macAddress = info.readString();
        String question1 = info.readString();
        String answer1 = info.readString();
        String question2 = info.readString();
        String answer2 = info.readString();
        String mInsertQuery = "INSERT INTO user_table (Name,UserName,Password,Email,MAC,Question1,Answer1,Question2,Answer2) Values('" + name + "','" + userName + "','" + password + "','" + email + "','" + macAddress + "','" + question1 + "','" + answer1 + "','" + question2 + "','" + answer2 + "')";
        try {
            Log.v(TAG, "default 1 : ");
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, "default 3 : " + mInsertQuery);
            insertUserData = mydatabase.rawQuery(mInsertQuery, null);
            Log.v(TAG, "default 2 : " + mInsertQuery);
            insertUserData.moveToNext();
            insertUserData = mydatabase.rawQuery("SELECT* FROM user_table", null);
            insertUserData.moveToFirst();
            int count = insertUserData.getCount();
            if (count == 1) {
                insertUserData = null;
                insertUserData = mydatabase.rawQuery("UPDATE user_table SET Userid = " + kUserIdBase, null);
                insertUserData.moveToNext();
                Parcel admin = Parcel.obtain();
                admin.writeInt(1);
                admin.writeInt(kUserIdBase);
                admin.setDataPosition(0);
                set_admin(admin);
            }
            insertUserData = null;
            insertUserData = mydatabase.rawQuery("SELECT Userid FROM user_table WHERE UserName = '" + userName + "'", null);
            insertUserData.moveToNext();
            int userId = insertUserData.getInt(0);
            info.setDataPosition(0);
            info.writeInt(userId);
            insertUserData.close();
            mydatabase.close();

            // default version insert
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            String versionQuery = "INSERT INTO version_state (version,last_updated_on," + "last_updated_time ,UserID) Values (0 , 0, 0," + userId + ")";
            Log.v(TAG, "default 1 : " + versionQuery + USER_DATA_BASE_LOCATION);
            insertUserData = mydatabase.rawQuery(versionQuery, null);
            insertUserData.moveToNext();
            insertUserData.close();
            mydatabase.close();
            // update data

        } catch (SQLiteException e) {
            e.printStackTrace();
            if (mydatabase != null) {
                mydatabase.close();
            }
            if (insertUserData != null) {
                insertUserData.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status setAdminPin(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor adminPinSet = null;
        info.setDataPosition(0);
        int adminPin = info.readInt();
        int userID = info.readInt();
        try {
            if (userID != 0 && adminPin != 0) {
                String data = "UPDATE user_table SET AdminPin=" + adminPin + " WHERE Userid = " + userID;
                mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
                adminPinSet = mydatabase.rawQuery(data, null);
                adminPinSet.moveToNext();
                adminPinSet.close();
                mydatabase.close();
            } else {
                status = CommonFile.DB_Status.STATUS_ERROR;
            }
        } catch (SQLiteException e) {
            if (adminPinSet != null) {
                adminPinSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status set_admin(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor adminSet = null;
        info.setDataPosition(0);
        int admin = info.readInt();
        int userID = info.readInt();
        try {
            String data = "UPDATE user_table SET Admin=" + admin + " WHERE Userid = " + userID;
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            adminSet = mydatabase.rawQuery(data, null);
            adminSet.moveToNext();
            adminSet.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (adminSet != null) {
                adminSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status delete_user(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor deleteUser = null;
        info.setDataPosition(0);
        int userID = info.readInt();
        try {
            String query = "DELETE FROM user_table Where Userid = " + userID;
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            deleteUser = mydatabase.rawQuery(query, null);
            if (deleteUser == null) {
                mydatabase.close();
                status = CommonFile.DB_Status.STATUS_NO_DATA;
                return status;
            }
            deleteUser.moveToNext();
            deleteUser.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (deleteUser != null) {
                deleteUser.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status check_admin(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor checkAdmin = null;
        info.setDataPosition(0);
        int userID = info.readInt();
        try {
            String check = "SELECT Admin FROM user_table Where Userid = " + userID;
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READONLY);
            checkAdmin = mydatabase.rawQuery(check, null);
            checkAdmin.moveToNext();
            int admin_result = checkAdmin.getInt(0);
            info.setDataPosition(0);
            info.writeInt(admin_result);
            checkAdmin.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (checkAdmin != null) {
                checkAdmin.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status verify_user(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        info.setDataPosition(0);
        String verfy = info.readString();
        switch (verfy) {
            case "verifyUserName": {
                String userName = info.readString();
                String user_query = "SELECT * FROM user_table Where UserName = '" + userName + "'";
                status = veify_all(user_query);
                break;
            }
            case "verifyOldPassword": {
                int userID = info.readInt();
                String oldPassword = info.readString();
                String user_query = "SELECT * FROM user_table Where UserId = " + userID + " AND Password = '" + oldPassword + "'";
                status = veify_all(user_query);
                break;
            }
            case "verifyMAC": {
                String MACID = info.readString();
                String mac_query = "SELECT * FROM user_table WHERE MAC='" + MACID + "'";
                status = veify_all(mac_query);
                break;
            }
            case "verifymail": {
                String email = info.readString();
                String email_query = "SELECT * FROM user_table WHERE Email='" + email + "'";
                status = veify_all(email_query);
                break;
            }
            case "verifyLogin": {
                String login_Name = info.readString();
                String password = info.readString();
                SQLiteDatabase mydatabase = null;
                Cursor sendUserId = null;
                String login_query = "SELECT Userid, Admin FROM user_table WHERE UserName='" + login_Name + "' AND Password ='" + password + "'";
                try {
                    mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READONLY);
                    sendUserId = mydatabase.rawQuery(login_query, null);
                    if (sendUserId.getCount() <= 0) {
                        status = CommonFile.DB_Status.STATUS_NO_DATA;
                        sendUserId.close();
                        mydatabase.close();
                        return status;
                    }
                    sendUserId.moveToNext();
                    int userId = sendUserId.getInt(0);
                    int admin = sendUserId.getInt(1);
                    info.setDataPosition(0);
                    info.writeInt(userId);
                    info.writeInt(admin);
                    sendUserId.close();
                    mydatabase.close();
                } catch (Exception e) {
                    if (sendUserId != null) {
                        sendUserId.close();
                    }
                    if (mydatabase != null) {
                        mydatabase.close();
                    }
                    status = CommonFile.DB_Status.STATUS_ERROR;
                }
                break;
            }
            case "verifyQuestion": {
                SQLiteDatabase mydatabase = null;
                Cursor sendUserId = null;
                String question = info.readString();
                String answer = info.readString();
                String uname = info.readString();
                //String question_query = "SELECT Userid FROM user_table WHERE Question1='" + question + "' AND Answer1='" + answer + "' OR Question2='" + question + "' AND Answer2='" + answer + "'";

                String question_query = "SELECT * FROM user_table WHERE UserName ='" + uname + "' AND ( Question1='" + question + "' AND Answer1='" + answer + "' OR Question2='" + question + "' AND Answer2='" + answer + "')";
                try {
                    mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READONLY);
                    sendUserId = mydatabase.rawQuery(question_query, null);
                    if (sendUserId.getCount() <= 0) {
                        status = CommonFile.DB_Status.STATUS_NO_DATA;
                        sendUserId.close();
                        mydatabase.close();
                        return status;
                    }
                    sendUserId.moveToNext();
                    int userId = sendUserId.getInt(0);
                    info.setDataPosition(0);
                    info.writeInt(userId);
                    sendUserId.close();
                    mydatabase.close();
                } catch (Exception e) {
                    if (sendUserId != null) {
                        sendUserId.close();
                    }
                    if (mydatabase != null) {
                        mydatabase.close();
                    }
                    status = CommonFile.DB_Status.STATUS_ERROR;
                }
                break;
            }
            case "verifyEntry": {
                String entry_query = "SELECT * FROM user_table";
                status = veify_all(entry_query);
                break;
            }
            default:
                Log.v(TAG, "default ");
                break;

        }

        return status;
    }

    private CommonFile.DB_Status veify_all(String s2) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor verification = null;
        Log.e(TAG, s2);
        try {
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READONLY);
            verification = mydatabase.rawQuery(s2, null);
            if (verification.getCount() <= 0) {
                status = CommonFile.DB_Status.STATUS_NO_DATA;
                mydatabase.close();
                verification.close();
                return status;
            }
            verification.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (verification != null) {
                verification.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status change_security(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        info.setDataPosition(0);
        String security = info.readString();
        switch (security) {
            case "questionUpdate": {
                int position = info.readInt();
                String question;
                String answer;
                if (position == 1) {
                    question = "Question1 ='" + info.readString();
                    answer = "',Answer1='" + info.readString();
                } else {
                    question = "Question2 ='" + info.readString();
                    answer = "',Answer2='" + info.readString();
                }
                int userID = info.readInt();
                String question_update_query = "UPDATE user_table SET " + question + answer + "' Where Userid = " + userID;
                status = change_data(question_update_query);
                break;
            }
            case "changePassword": {
                String password = info.readString();
                int userID = info.readInt();
                String password_query = "UPDATE user_table SET Password ='" + password + "' Where Userid = " + userID;
                status = change_data(password_query);
                break;
            }
            case "resetPassword": {
                int userID = info.readInt();
                String old = info.readString();
                String password = info.readString();
                String password_query = "UPDATE user_table SET Password ='" + password + "' Where Userid = " + userID + " AND Password = '" + old + "'";
                status = change_data(password_query);
                break;
            }
            default: {
                Log.v(TAG, "default  : " + security);
                break;
            }
        }
        return status;
    }

    private CommonFile.DB_Status get_security(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor cursor = null;
        info.setDataPosition(0);
        String user = info.readString();
        Log.v(TAG, "Get security questions for user : " + user);
        String query = "SELECT * FROM user_table Where UserName = '" + user + "'";
        try {
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READONLY);
            cursor = mydatabase.rawQuery(query, null);
            if ((cursor == null) || (cursor.getCount() <= 0)) {
                status = CommonFile.DB_Status.STATUS_NO_DATA;
                if (cursor != null) {
                    cursor.close();
                }
                mydatabase.close();
                return status;
            }
            info.setDataPosition(0);
            while (cursor.moveToNext()) {
                String que1 = cursor.getString(cursor.getColumnIndex("Question1"));
                Log.v(TAG, "que1 : " + que1);
                info.writeString(que1);
                String que2 = cursor.getString(cursor.getColumnIndex("Question2"));
                Log.v(TAG, "que2 : " + que2);
                info.writeString(que2);
            }
            cursor.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (cursor != null) {
                cursor.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;

    }

    private CommonFile.DB_Status change_data(String s2) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor verification = null;
        try {
            mydatabase = SQLiteDatabase.openDatabase(DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            verification = mydatabase.rawQuery(s2, null);
            if (verification == null) {
                status = CommonFile.DB_Status.STATUS_NO_DATA;
                if (verification != null) {
                    verification.close();
                }
                mydatabase.close();
                return status;
            }
            verification.moveToNext();
            verification.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (verification != null) {
                verification.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status setFavourite(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor insertFavouriteData = null;
        info.setDataPosition(0);
        int CNumber = info.readInt();
        String CName = info.readString();
        int UserID = info.readInt();
        int versionUpdate = info.readInt();
        info.setDataPosition(0);
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            // check count
            String checkFavouriteCount = "SELECT COUNT(*) FROM Favourite";
            insertFavouriteData = mydatabase.rawQuery(checkFavouriteCount, null);
            insertFavouriteData.moveToNext();
            if (insertFavouriteData != null && insertFavouriteData.getInt(0) > 100) {
                if (insertFavouriteData != null) {
                    insertFavouriteData.close();
                }
                if (mydatabase != null) {
                    mydatabase.close();
                }
                info.writeInt(1);
                return status;
            } else {
                info.writeInt(0);
            }
            String insertQuery = "INSERT INTO Favourite (CNumber,CName,UserID) Values(" + CNumber + " ,'" + CName + "'," + UserID + ")";
            insertFavouriteData = mydatabase.rawQuery(insertQuery, null);
            insertFavouriteData.moveToNext();
            if (versionUpdate == 1) {
                // update version
                int[] data = getCurrentDateTime();
                insertQuery = "UPDATE version_state SET version = version+1, last_updated_on = " + data[0] + " , last_updated_time = " + data[1] + " WHERE UserID = " + UserID;
                insertFavouriteData = mydatabase.rawQuery(insertQuery, null);
                insertFavouriteData.moveToNext();
            }
            insertFavouriteData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (insertFavouriteData != null) {
                insertFavouriteData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status fetchFavourite(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor fetchFavouriteData = null;
        info.setDataPosition(0);
        int UserID = info.readInt();
        info.setDataPosition(0);
        String mInsertQuery = "SELECT CNumber FROM Favourite WHERE UserID = " + UserID;
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, "default " + USER_DATA_BASE_LOCATION + " now query = " + mInsertQuery);
            fetchFavouriteData = mydatabase.rawQuery(mInsertQuery, null);
            if (fetchFavouriteData != null) {
                info.writeInt(fetchFavouriteData.getCount());
                while (fetchFavouriteData.moveToNext()) {
                    int channel_no = fetchFavouriteData.getInt(0);
                    info.writeInt(channel_no);
                }
            }
            fetchFavouriteData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (mydatabase != null) {
                fetchFavouriteData.close();
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status checkFavourite(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor checkFavouriteData = null;
        info.setDataPosition(0);
        int channel = info.readInt();
        int UserID = info.readInt();
        info.setDataPosition(0);
        String mInsertQuery = "SELECT * FROM Favourite WHERE CNumber = " + channel + " AND UserID = " + UserID;
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, "default " + USER_DATA_BASE_LOCATION + " now query = " + mInsertQuery);
            checkFavouriteData = mydatabase.rawQuery(mInsertQuery, null);
            if (checkFavouriteData == null || checkFavouriteData.getCount() <= 0) {
                Log.v(TAG, "default no favourite");
                status = CommonFile.DB_Status.STATUS_NO_DATA;
            }
            checkFavouriteData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (mydatabase != null) {
                checkFavouriteData.close();
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status removeFavourite(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor removeFavouriteData = null;
        info.setDataPosition(0);
        int channel = info.readInt();
        int UserID = info.readInt();
        int versionUpdate = info.readInt();
        info.setDataPosition(0);
        String mInsertQuery = "DELETE FROM Favourite WHERE CNumber = " + channel + " AND UserID = " + UserID;
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, "default " + DATA_BASE_LOCATION + " now query = " + mInsertQuery);
            removeFavouriteData = mydatabase.rawQuery(mInsertQuery, null);
            removeFavouriteData.moveToNext();
            if (versionUpdate == 1) {
                Log.e(TAG, "favourite remove");
                //version update
                int[] data = getCurrentDateTime();
                mInsertQuery = "UPDATE version_state SET version = version+1, last_updated_on = " + data[0] + " , last_updated_time = " + data[1] + " WHERE UserID = " + UserID;
                removeFavouriteData = mydatabase.rawQuery(mInsertQuery, null);
                removeFavouriteData.moveToNext();
            }
            removeFavouriteData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (removeFavouriteData != null) {
                removeFavouriteData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status checkUserDataVersion(Parcel info) {
        Log.v(TAG, "get_DB_Version_Details");
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor resultSet = null;
        info.setDataPosition(0);
        int UseId = info.readInt();
        info.setDataPosition(0);
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READONLY);
            resultSet = mydatabase.rawQuery("SELECT * FROM version_state WHERE UserID = " + UseId, null);
            int count = resultSet.getCount();
            if (count <= 0) {
                status = CommonFile.DB_Status.STATUS_NO_DATA;
                mydatabase.close();
                resultSet.close();
                return status;
            }
            if (resultSet != null) {
                resultSet.moveToNext();
                int version = resultSet.getInt(resultSet.getColumnIndex("version"));
                info.writeInt(version);
                int date = resultSet.getInt(resultSet.getColumnIndex("last_updated_on"));
                info.writeInt(date);
                int time = resultSet.getInt(resultSet.getColumnIndex("last_updated_time"));
                info.writeInt(time);
            }
            if (resultSet != null) {
                resultSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
        } catch (SQLiteException e) {
            if (resultSet != null) {
                resultSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        return status;
    }


    private CommonFile.DB_Status addReminder(Parcel info) {
        Log.v(TAG, "add reminder");
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor resultSet = null;
        info.setDataPosition(0);
        int CNumber = info.readInt();
        String channelName = info.readString();
        String program_name = info.readString();
        int date = info.readInt();
        int start_time = info.readInt();
        int end_time = info.readInt();
        int repeat = info.readInt();
        int userId = info.readInt();
        int versionUpdate = info.readInt();
        info.setDataPosition(0);
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            resultSet = mydatabase.rawQuery("SELECT * FROM Reminder WHERE program_name ='" + program_name + "' AND CNumber=" + CNumber + " AND UserID = " + userId + " AND date = " + date, null);
            Log.e(TAG, "query :" + "SELECT * FROM Reminder WHERE program_name ='" + program_name + "' AND CNumber=" + CNumber + " AND UserID = " + userId + " AND date = " + date);
            if (resultSet.getCount() > 0) {
                Log.w(TAG, "Entry already exists.. IGNORING.. Count : " + resultSet.getCount());
                info.writeInt(1);
                resultSet.close();
                mydatabase.close();
                status = CommonFile.DB_Status.STATUS_ERROR;
                return status;
            }
            String insertQuery = "INSERT INTO Reminder Values(" + CNumber + " ,'" + channelName + "', '" + program_name + "', " + date + ", " + start_time + ", " + end_time + ", " + repeat + ", " + userId + ")";
            resultSet = mydatabase.rawQuery(insertQuery, null);
            if (versionUpdate == 1) {
                resultSet.moveToNext();
                Log.e(TAG, "reminder  add");
                // version date and time update
                int[] data = getCurrentDateTime();
                String versionQuery = "UPDATE version_state SET version = version+1, last_updated_on = " + data[0] + " , last_updated_time = " + data[1] + " WHERE UserID = " + userId;
                //end version data
                resultSet = mydatabase.rawQuery(versionQuery, null);
            }
            resultSet.moveToNext();
            resultSet.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (resultSet != null) {
                resultSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            if (resultSet != null) {
                resultSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (Exception e) {
            if (resultSet != null) {
                resultSet.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    private CommonFile.DB_Status removeReminder(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor removeReminderData = null;
        info.setDataPosition(0);
        int UserID = info.readInt();
        int CNumber = info.readInt();
        int startTime = info.readInt();
        int date = info.readInt();
        int deleteMode = info.readInt();
        int versionUpdate = info.readInt();
        Log.e(TAG, "default Pradeep: " + deleteMode);
        String mDeleteReminderQuery;
        info.setDataPosition(0);
        mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
        if (deleteMode == 1) {
            mDeleteReminderQuery = "DELETE FROM Reminder WHERE start_time = " + startTime + " AND CNumber =" + CNumber + " AND date =" + date + " AND UserID = " + UserID;
        } else {
            String dateQuery = "SELECT date FROM Reminder WHERE start_time = " + startTime + " AND UserID = " + UserID + " AND CNumber = " + CNumber;
            removeReminderData = mydatabase.rawQuery(dateQuery, null);
            removeReminderData.moveToNext();
            int lodDate = removeReminderData.getInt(0);
            mDeleteReminderQuery = "UPDATE Reminder SET date = " + getNextDate("" + lodDate) + " WHERE start_time = " + startTime + " AND UserID = " + UserID + " AND CNumber = " + CNumber;
        }
        try {
            Log.v(TAG, "default " + USER_DATA_BASE_LOCATION + " now query = " + mDeleteReminderQuery);
            removeReminderData = mydatabase.rawQuery(mDeleteReminderQuery, null);
            if (versionUpdate == 1) {
                removeReminderData.moveToNext();
                Log.e(TAG, "update version data");
                // version update
                int[] data = getCurrentDateTime();
                String versionQuery = "UPDATE version_state SET version = version+1, last_updated_on = " + data[0] + " , last_updated_time = " + data[1] + " WHERE UserID = " + UserID;
                //end version data
                removeReminderData = mydatabase.rawQuery(versionQuery, null);
            }
            removeReminderData.moveToNext();
            //end version data
            removeReminderData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (removeReminderData != null) {
                removeReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            if (removeReminderData != null) {
                removeReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }


    public static String getNextDate(String oldDate) {
        final SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        final Date date;
        final Calendar calendar = Calendar.getInstance();
        try {
            date = format.parse(oldDate);
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return format.format(calendar.getTime());
    }


    private CommonFile.DB_Status fetchReminder(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor fetchReminderData = null;
        info.setDataPosition(0);
        int UserID = info.readInt();
        info.setDataPosition(0);
        String mFetchReminderQuery = "SELECT * FROM Reminder WHERE UserID = " + UserID + " ORDER BY date ASC, start_time ASC";
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, "default " + USER_DATA_BASE_LOCATION + " now query = " + mFetchReminderQuery);
            fetchReminderData = mydatabase.rawQuery(mFetchReminderQuery, null);
            if (fetchReminderData == null && fetchReminderData.getCount() <= 0) {
                if (fetchReminderData != null) {
                    fetchReminderData.close();
                }
                if (mydatabase != null) {
                    mydatabase.close();
                }
                status = CommonFile.DB_Status.STATUS_ERROR;
                return status;
            }
            info.writeInt(fetchReminderData.getCount());
            while (fetchReminderData.moveToNext()) {
                int channel_no = fetchReminderData.getInt(fetchReminderData.getColumnIndex("CNumber"));
                info.writeInt(channel_no);
                String channel_name = fetchReminderData.getString(fetchReminderData.getColumnIndex("channel_name"));
                info.writeString(channel_name);
                String program_name = fetchReminderData.getString(fetchReminderData.getColumnIndex("program_name"));
                info.writeString(program_name);
                int start_time = fetchReminderData.getInt(fetchReminderData.getColumnIndex("start_time"));
                info.writeInt(start_time);
                int end_time = fetchReminderData.getInt(fetchReminderData.getColumnIndex("end_time"));
                info.writeInt(end_time);
                int date = fetchReminderData.getInt(fetchReminderData.getColumnIndex("date"));
                info.writeInt(date);
                int repeat = fetchReminderData.getInt(fetchReminderData.getColumnIndex("repeat"));
                info.writeInt(repeat);
            }
            fetchReminderData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (fetchReminderData != null) {
                fetchReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            if (fetchReminderData != null) {
                fetchReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status checkRecordData(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor getReminderData = null;
        info.setDataPosition(0);
        String file = info.readString();
        info.setDataPosition(0);
        String mFetchReminderQuery = "SELECT last_view_on FROM Record_data WHERE file = '" + file + "'";
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, " now query = " + mFetchReminderQuery);
            getReminderData = mydatabase.rawQuery(mFetchReminderQuery, null);
            if (getReminderData == null || getReminderData.getCount() <= 0) {
                String deleteQuery = "INSERT INTO Record_data (file,last_view_on) Values('" + file + "' , 0);";
                info.writeInt(0);
                getReminderData = mydatabase.rawQuery(deleteQuery, null);
                getReminderData.moveToNext();
                if (getReminderData != null) {
                    getReminderData.close();
                }
                if (mydatabase != null) {
                    mydatabase.close();
                }
                status = CommonFile.DB_Status.STATUS_ERROR;
                return status;
            }
            info.writeInt(getReminderData.getCount());
            while (getReminderData.moveToNext()) {
                int channel_no = getReminderData.getInt(0);
                info.writeInt(channel_no);
            }
            getReminderData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status updateRecordData(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor getReminderData = null;
        info.setDataPosition(0);
        String file = info.readString();
        int last_view_on = info.readInt();
        info.setDataPosition(0);
        String mFetchReminderQuery = "UPDATE Record_data SET last_view_on = " + last_view_on + " WHERE file = '" + file + "'";
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, " now query = " + mFetchReminderQuery);
            getReminderData = mydatabase.rawQuery(mFetchReminderQuery, null);

            getReminderData.moveToNext();
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
        } catch (SQLiteException e) {
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private CommonFile.DB_Status getOccurredReminders(Parcel info) {
        CommonFile.DB_Status status = CommonFile.DB_Status.STATUS_OK;
        SQLiteDatabase mydatabase = null;
        Cursor getReminderData = null;
        info.setDataPosition(0);
        int userID = info.readInt();
        int date = info.readInt();
        int startTime = info.readInt();
        info.setDataPosition(0);
        String mFetchReminderQuery = "SELECT * FROM Reminder WHERE UserID = " + userID + " AND date = " + date + " AND start_time = " + startTime;
        try {
            mydatabase = SQLiteDatabase.openDatabase(USER_DATA_BASE_LOCATION, null, SQLiteDatabase.OPEN_READWRITE);
            Log.v(TAG, " now query = " + mFetchReminderQuery);
            getReminderData = mydatabase.rawQuery(mFetchReminderQuery, null);
            if (getReminderData == null || getReminderData.getCount() <= 0) {
                if (getReminderData != null) {
                    getReminderData.close();
                }
                if (mydatabase != null) {
                    mydatabase.close();
                }
                status = CommonFile.DB_Status.STATUS_ERROR;
                return status;
            }
            info.writeInt(getReminderData.getCount());
            while (getReminderData.moveToNext()) {
                int channel_no = getReminderData.getInt(getReminderData.getColumnIndex("CNumber"));
                info.writeInt(channel_no);
                String channel_name = getReminderData.getString(getReminderData.getColumnIndex("channel_name"));
                info.writeString(channel_name);
                String program_name = getReminderData.getString(getReminderData.getColumnIndex("program_name"));
                info.writeString(program_name);
            }
            // update and delete reminder
            String deleteQuery = "UPDATE Reminder SET date = " + getNextDate("" + date) + " WHERE start_time = " + startTime + " AND repeat = 1  AND date = " + date;
            getReminderData = mydatabase.rawQuery(deleteQuery, null);
            getReminderData.moveToNext();
            deleteQuery = "DELETE FROM Reminder WHERE date < " + date + " OR start_time <= " + startTime + " AND date = " + date;
            getReminderData = mydatabase.rawQuery(deleteQuery, null);
            getReminderData.moveToNext();
            getReminderData.close();
            mydatabase.close();
        } catch (SQLiteException e) {
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            status = CommonFile.DB_Status.STATUS_ERROR;
        } catch (NullPointerException e) {
            if (getReminderData != null) {
                getReminderData.close();
            }
            if (mydatabase != null) {
                mydatabase.close();
            }
            e.printStackTrace();
            status = CommonFile.DB_Status.STATUS_ERROR;
        }
        return status;
    }

    private int[] getCurrentDateTime() {
        // version date and time update
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month = Calendar.getInstance().get(Calendar.MONTH);
        month += 1;
        int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        int date = ((year * 100) + month) * 100 + day;
        int hours = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int minutes = Calendar.getInstance().get(Calendar.MINUTE);
        int seconds = Calendar.getInstance().get(Calendar.SECOND);
        int time = ((hours * 100) + minutes) * 100 + seconds;
        return new int[]{date, time};
    }


}

