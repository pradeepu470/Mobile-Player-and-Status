package com.pradeep.videoplayercollection;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcel;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.pradeep.videoplayercollection.dbase.UserDatabaseAccess;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by pradeep on 21-06-2019.
 */

public class ForgotPasswordActivity extends AppCompatActivity {
    private final String TAG = "ForgotPasswordActivity";
    private ProgressBar mTaskInProgress;
    private EditText inputUserName, inputPassword, inputConfrmPassword, inputAnswer;
    private LinearLayout mQuestionPaswContainer;
    private Button  mFinalSendButton;
    private Spinner mQuestionSpiner;
    private TextView mReqStatus;
    private String mSelectedQuestion, mSelectedUser;
    private ArrayAdapter<String> mQuestionAdapter;
    private ArrayList<String> mQuestionList;
    private UserDatabaseAccess mDVBUserDatabase = null;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        mDVBUserDatabase = UserDatabaseAccess.getInstance(this);
        mTaskInProgress = (ProgressBar) findViewById(R.id.progressBar);
        mReqStatus = (TextView) findViewById(R.id.status);
        inputUserName = (EditText) findViewById(R.id.username);
        inputPassword = (EditText) findViewById(R.id.password);
        inputConfrmPassword = (EditText) findViewById(R.id.confirm_pass);
        inputAnswer = (EditText) findViewById(R.id.input_ans);
        mQuestionPaswContainer = (LinearLayout) findViewById(R.id.ques_psw_container);
        mQuestionSpiner = (Spinner) findViewById(R.id.question1);
        mFinalSendButton = (Button) findViewById(R.id.final_send);
        inputAnswer.setEnabled(false);
        inputConfrmPassword.setEnabled(false);
        inputPassword.setEnabled(false);
        mFinalSendButton.setEnabled(false);
        mQuestionList = new ArrayList<String>();
        final View decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                hideSystemUI();
            }
        });
        disableCopyPaste(inputUserName);
        disableCopyPaste(inputPassword);
        disableCopyPaste(inputConfrmPassword);
        disableCopyPaste(inputAnswer);
        mQuestionSpiner = (Spinner) findViewById(R.id.question1);
        mQuestionAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, mQuestionList) {
            @Override
            public boolean isEnabled(int position) {
                if (position == 0) {
                    return false;
                } else {
                    return true;
                }
            }

            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if (position == 0) {
                    tv.setTextColor(Color.GRAY);
                } else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        mQuestionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mQuestionSpiner.setAdapter(mQuestionAdapter);
        mQuestionSpiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (position > 0) {
                    mSelectedQuestion = item;
                } else {
                    mSelectedQuestion = null;
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        inputUserName.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String username = inputUserName.getText().toString();
                if (username.isEmpty() || !validateUserName(username)) {
                    inputUserName.setError("Enter at least 3 characters");
                } else {
                    inputUserName.setError(null);
                    mReqStatus.setVisibility(View.GONE);
                    getSecurityQuestions(username);
                    mSelectedUser = username;
                }
            }
        });

        mFinalSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mReqStatus.setVisibility(View.GONE);
                String answer = inputAnswer.getText().toString();
                String passwd = inputPassword.getText().toString();
                String conf_passwd = inputConfrmPassword.getText().toString();
                if (mSelectedQuestion == null) {
                    mReqStatus.setText("Select a Security Question");
                    mReqStatus.setVisibility(View.VISIBLE);
                } else if (answer.isEmpty() || !validateAnswer(answer)) {
                    inputAnswer.setError("Please enter correct security Answer");
                } else if (passwd.isEmpty() || !validatePassword(passwd)) {
                    inputPassword.setError("Password must between 8 and 15 alphanumeric characters and Atleast 1 letter, 1 number, 1 special character and SHOULD NOT start with a special character ");
                } else if (conf_passwd.isEmpty() || !conf_passwd.equals(passwd)) {
                    inputConfrmPassword.setError("Password doesn't match");
                } else {
                    verifyAndUpdatePassword(mSelectedQuestion,answer, passwd);
                }
            }
        });
    }

    private void getSecurityQuestions(String username) {
        showProgressBar();
        Parcel info = Parcel.obtain();
        info.writeString(username);
        info.setDataPosition(0);
        if(mQuestionList.size() > 0){
            mQuestionList.clear();
        }
        mQuestionList.add("Select Security Question..");
        CommonFile.DB_Status result_data = mDVBUserDatabase.fetchUserData(info,CommonFile.kActionGetSecurity);
        info.setDataPosition(0);
        if (result_data == CommonFile.DB_Status.STATUS_OK) {
            String ques1 = info.readString();
            String ques2 = info.readString();
            mQuestionList.add(ques1);
            mQuestionList.add(ques2);
            mQuestionAdapter.notifyDataSetChanged();
            mFinalSendButton.setEnabled(true);
            inputUserName.setEnabled(false);
            inputPassword.setEnabled(true);
            inputConfrmPassword.setEnabled(true);
            inputAnswer.setEnabled(true);
        } else{
            mReqStatus.setVisibility(View.VISIBLE);
            mReqStatus.setText("Incorrect userName");
        }
        hideProgressBar();
    }

    private void showProgressBar() {
        Log.v(TAG, "showProgressBar");
        if (mTaskInProgress.getVisibility() != View.VISIBLE) {
            Log.v(TAG, "showProgressBar.....");
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            mTaskInProgress.setVisibility(View.VISIBLE);
        }
    }

    private void hideProgressBar() {
        Log.v(TAG, "hideProgressBar");
        if (mTaskInProgress.getVisibility() == View.VISIBLE) {
            Log.v(TAG, "hideProgressBar.....");
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            mTaskInProgress.setVisibility(View.GONE);
        }
    }

    private void verifyAndUpdatePassword(String question, String answer,String password) {
        Log.v(TAG, "verify And Update Password");
        showProgressBar();
        Parcel info = Parcel.obtain();
        info.writeString("verifyQuestion");
        info.writeString(question);
        info.writeString(answer);
        info.writeString(mSelectedUser);
        info.setDataPosition(0);
        CommonFile.DB_Status result_data = mDVBUserDatabase.fetchUserData(info,CommonFile.kActionVerfyUser);
        info.setDataPosition(0);
        if (result_data == CommonFile.DB_Status.STATUS_OK) {
            int userId = info.readInt();
            Log.v(TAG, "Update Password: "+userId);
            Parcel info1 = Parcel.obtain();
            info1.writeString("changePassword");
            info1.writeString(password);
            info1.writeInt(userId);
            info1.setDataPosition(0);
            CommonFile.DB_Status result_data1 = mDVBUserDatabase.fetchUserData(info1,CommonFile.kActionChangeSecurity);
            info1.setDataPosition(0);
            if (result_data1 == CommonFile.DB_Status.STATUS_OK) {
                Toast.makeText(getApplicationContext(), "Password changed successfully.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            } else{
                mReqStatus.setVisibility(View.VISIBLE);
                mReqStatus.setText("Failed to update password");
            }
        } else {
            Log.v(TAG, "Update error: ");
            mReqStatus.setText("Incorrect answer to security Question");
            mReqStatus.setVisibility(View.VISIBLE);
            inputAnswer.setText("");
            inputPassword.setText("");
            inputConfrmPassword.setText("");
        }
        hideProgressBar();
    }

    private boolean validateUserName(final String username) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^[A-Za-z0-9@#$&_.-]{3,19}+$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(username);
        return matcher.matches();

    }

    private boolean validateAnswer(final String answer) {
        Pattern pattern;
        Matcher matcher;
        final String ANSWER_PATTERN = "^(?:[a-zA-Z0-9 ]{3,19}+)?$";
        pattern = Pattern.compile(ANSWER_PATTERN);
        matcher = pattern.matcher(answer);
        return matcher.matches();

    }

    private boolean validatePassword(final String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$&_])[A-Za-z\\d][A-Za-z\\d@#$&_]{7,19}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }

    private void disableCopyPaste(EditText textField){
        textField.setCustomSelectionActionModeCallback(new ActionMode.Callback() {
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                menu.clear();
                return false;
            }
            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                return false;
            }

            public void onDestroyActionMode(ActionMode actionMode) {
            }
        });
        textField.setLongClickable(false);
        textField.setTextIsSelectable(false);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE);

        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
                | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

}
