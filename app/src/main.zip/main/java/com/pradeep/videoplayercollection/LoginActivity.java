package com.pradeep.videoplayercollection;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Parcel;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.pradeep.videoplayercollection.dbase.UserDatabaseAccess;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by pradeep on 28-11-2018.
 */

public class LoginActivity extends AppCompatActivity {

    private SessionManager mSession;
    private EditText inputUserName, inputPassword;
    private Button mLoginButton;
    private String TAG = "LoginActivity";
    private UserDatabaseAccess mDVBUserDatabase = null;
    private Activity mActivity;
    private TextView mLoginStatus;
    private TextView mRegisterButton;
    private TextView mMainActivity;
    private TextView mForgotPasswordButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.activity_login);
        mDVBUserDatabase = UserDatabaseAccess.getInstance(this);
        mActivity = this;
        inputUserName = (EditText) findViewById(R.id.username);
        inputPassword = (EditText) findViewById(R.id.password);
        mLoginButton = (Button) findViewById(R.id.loginButton);
        mLoginStatus = (TextView) findViewById(R.id.status);
        mSession = SessionManager.getInstance(LoginActivity.this);
        mRegisterButton = (TextView) findViewById(R.id.register);
        mMainActivity = (TextView) findViewById(R.id.mainAcitivity);
        mForgotPasswordButton = (TextView) findViewById(R.id.forgot_psw);
        if (mSession.isLoggedIn()) {
            Intent registerScreen = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(registerScreen);
            finish();
        }
        disableCopyPaste(inputUserName);
        disableCopyPaste(inputPassword);
        addClickListener();
    }


    void addClickListener() {
        mMainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerScreen = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(registerScreen);
                finish();
            }
        });
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginStatus.setVisibility(View.GONE);
                mActivity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                if (validate()) {
                    final String user = inputUserName.getText().toString();
                    final String password = inputPassword.getText().toString();
                    Parcel info = Parcel.obtain();
                    info.setDataPosition(0);
                    info.writeString("verifyLogin");
                    info.writeString(user);
                    info.writeString(password);
                    info.setDataPosition(0);
                    CommonFile.DB_Status result_data = mDVBUserDatabase.fetchUserData(info, CommonFile.kActionVerfyUser);
                    if (result_data == CommonFile.DB_Status.STATUS_OK) {
                        Toast.makeText(LoginActivity.this, "Login Done", Toast.LENGTH_LONG).show();
                        info.setDataPosition(0);
                        int user_id = info.readInt();
                        mSession.setLogin(true, user_id);
                        Log.e(TAG, "loging done" + user_id);
                        mActivity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                        return;
                    } else {
                        // TODO: Temp hack to avoid registration. Remove post initial setup wizard... start
                        if (user.equals(password) == true) {
                            Toast.makeText(LoginActivity.this, "Provided Temp login", Toast.LENGTH_SHORT).show();
                            mSession.setLogin(true, 1001);
                            mActivity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                            return;
                        }
                        // end
                        mLoginStatus.setVisibility(View.VISIBLE);
                        mLoginStatus.setText("Please Enter Correct User Id and Password");
                        //Toast.makeText(LoginActivity.this, "Please Enter Correct User Id and Password", Toast.LENGTH_SHORT).show();
                    }

                }
                mActivity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            }
        });
        mRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog recordResume = new Dialog(LoginActivity.this);
                recordResume.setContentView(R.layout.register_popup);
                final ImageButton resume = (ImageButton) recordResume.findViewById(R.id.btn_local);
                resume.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recordResume.dismiss();
                        Intent registerScreen = new Intent(LoginActivity.this, FaceBookActivity.class);
                        startActivity(registerScreen);
                        finish();
                    }
                });
                ImageButton restart = (ImageButton) recordResume.findViewById(R.id.btn_facebook);
                restart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recordResume.dismiss();
                        Intent registerScreen = new Intent(LoginActivity.this, RegistrationActivity.class);
                        startActivity(registerScreen);
                        finish();
                    }
                });
                recordResume.setCancelable(false);
                recordResume.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                recordResume.show();
            }
        });

        mForgotPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginStatus.setVisibility(View.GONE);
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            }
        });
        final View decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                hideSystemUI();
            }
        });
    }

    private boolean validate() {
        boolean valid = true;
        String username = inputUserName.getText().toString();
        String password = inputPassword.getText().toString();

        if (username.isEmpty() || !validateUserName(username)) {
            inputUserName.setError("Enter at least 3 characters");
            valid = false;
        } else {
            inputUserName.setError(null);
        }

        if (password.isEmpty() || !validatePassword(password)) {
            inputPassword.setError("Password must between 8 and 15 alphanumeric characters and Atleast 1 letter, 1 number, 1 special character and SHOULD NOT start with a special character ");
            valid = false;
        } else {
            inputPassword.setError(null);
        }

        return valid;
    }

    private boolean validatePassword(final String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[@#$&_])[A-Za-z\\d][A-Za-z\\d@#$&_]{7,19}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }

    private boolean validateUserName(final String username) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^[A-Za-z@#$&_]{3,20}+$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(username);
        return matcher.matches();

    }

    private void disableCopyPaste(EditText textField) {
        textField.setCustomSelectionActionModeCallback(new ActionMode.Callback() {
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                menu.clear();
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                return false;
            }

            public void onDestroyActionMode(ActionMode actionMode) {
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE);

        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
                | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
                | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }


}
