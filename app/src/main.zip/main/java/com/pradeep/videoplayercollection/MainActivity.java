package com.pradeep.videoplayercollection;

import android.Manifest;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.CardView;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Spinner;

import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.CALL_PHONE;
import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.SEND_SMS;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, AdapterView.OnItemSelectedListener, RecognitionListener {
    private final String TAG = "MainActivity";
    private static final String USER_DATA_BASE_LOCATION = "/data/data/com.pradeep.videoplayercollection/databases/userdata.db";
    private SessionManager mSession;
    private ProgressBar mTaskInProgress;
    private MediaRecorder recorder;
    private File audiofile = null;
    private Context mContext;
    private String mPhoneNumber;
    private ArrayList<String> mPhoneNumberList;
    public static final int RequestPermissionCode = 1;
    private SearchViewAdapter mSearchViewAdapter;
    private Dialog mDisplayPopup;
    private SpeechRecognizer speech = null;
    private Intent recognizerIntent;
    private ImageView listenerVoice;
    private TextView mVoiceText;
    private Boolean mVoiceListener = false;
    @Override
    protected void onDestroy() {
        Log.v(TAG, "onDestroy, state : ");
        super.onDestroy();
    }
    @Override
    protected void onPause() {
        Log.v(TAG, "onPause");
        super.onPause();
    }
    @Override
    protected void onResume() {
        Log.v(TAG, "onResume");
        super.onResume();
    }
    @Override
    public void onBackPressed() {
        if (mDisplayPopup != null) {
            if (speech != null) {
                speech.destroy();
                Log.d("Log", "destroy");
            }
            mDisplayPopup.dismiss();
            mDisplayPopup = null;
            return;
        } else {
            finish();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v(TAG, "onCreate");
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mTaskInProgress = (ProgressBar) findViewById(R.id.main_progress_bar);
        listenerAllRequest();
        mContext = this;
        if (checkPermission()) {
            Toast.makeText(MainActivity.this, "All Permissions Granted Successfully", Toast.LENGTH_LONG).show();
        } else {
            requestPermission();
        }

    }
    private void listenerAllRequest() {
        CardView image = (CardView) findViewById(R.id.image);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....image");
                    Intent i = new Intent(MainActivity.this, GalleryImageData.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });
        CardView video = (CardView) findViewById(R.id.video);
        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....video");
                    Intent i = new Intent(MainActivity.this, RecordPlaybackActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });
        CardView audio = (CardView) findViewById(R.id.audio);
        audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....audio");
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });

        CardView otherFile = (CardView) findViewById(R.id.other_file);
        otherFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....other_file");
                    Intent i = new Intent(MainActivity.this, AppDisplayActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });
        CardView speechListener = (CardView) findViewById(R.id.speech_listener);
        speechListener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....speech_listener");
                    speechToText();
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });
        CardView textToSpeech = (CardView) findViewById(R.id.text_to_speech);
        textToSpeech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....speechListener");
                    Intent i = new Intent(MainActivity.this, TextSpeech.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }

            }
        });

        CardView recorder = (CardView) findViewById(R.id.recorder);
        recorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    Log.v(TAG, "Profile....VoiceRecorder");
                    voiceRecorder();
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });
        CardView phoneDetail = (CardView) findViewById(R.id.phone_detail);
        phoneDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    phoneDetails();
                    Log.v(TAG, "Profile....phone Details");
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }
        });
        CardView sms = (CardView) findViewById(R.id.sms);
        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission()) {
                    showProgressBar();
                    Log.v(TAG, "Profile....sms");
                    if (mPhoneNumberList == null) {
                        mPhoneNumberList = new ArrayList<>();
                    } else {
                        mPhoneNumberList.clear();
                    }
                    ArrayList<Object> temp = getContactList();
                    smsSendDisplay(temp);
                } else {
                    Toast.makeText(MainActivity.this, "Permission not allow", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
        } else if (id == R.id.nav_guide) {

        } else if (id == R.id.nav_organize) {

        } else if (id == R.id.reset_password) {
            finish();
        } else if (id == R.id.logout) {
            finish();
            return true;
        } else if (id == R.id.nav_settings) {

        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showProgressBar() {
        Log.e(TAG, "pradeep");
        if (mTaskInProgress.getVisibility() != View.VISIBLE) {
            Log.v(TAG, "pradeep visible");
            MainActivity.this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            mTaskInProgress.setVisibility(View.VISIBLE);
        }
    }

    private void hideProgressBar() {
        Log.v(TAG, "pradeep hide");
        if (mTaskInProgress.getVisibility() == View.VISIBLE) {
            Log.v(TAG, "pradeep gone visible");
            MainActivity.this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            mTaskInProgress.setVisibility(View.GONE);
        }
    }

    private void voiceRecorder() {
        final Dialog voiceRecorderData = new Dialog(mContext);
        voiceRecorderData.setContentView(R.layout.voice_recorder_view);
        final LinearLayout mainLayout = (LinearLayout) findViewById(R.id.mainLayout);
        LinearLayout otherLayout = (LinearLayout) voiceRecorderData.findViewById(R.id.recordLayout);
        mainLayout.setVisibility(View.GONE);
        otherLayout.setVisibility(View.VISIBLE);
        final Button recordStart = (Button) voiceRecorderData.findViewById(R.id.start_record);
        final Button stopStart = (Button) voiceRecorderData.findViewById(R.id.stop_record);
        recordStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TAG, "Profile....start record");
                recordStart.setEnabled(false);
                stopStart.setEnabled(true);
                startRecording();
            }
        });
        stopStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TAG, "Profile....stop record");
                recordStart.setEnabled(true);
                stopStart.setEnabled(false);
                stopRecording();
                voiceRecorderData.dismiss();
                mainLayout.setVisibility(View.VISIBLE);
            }
        });
        voiceRecorderData.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        voiceRecorderData.show();
        voiceRecorderData.setCancelable(false);
    }

    public void startRecording() {
        File dir = Environment.getExternalStorageDirectory();
        try {
            audiofile = File.createTempFile("sound", ".3gp", dir);
        } catch (IOException e) {
            Log.e(TAG, "external storage access error");
            return;
        }
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        recorder.setOutputFile(audiofile.getAbsolutePath());
        try {
            recorder.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        recorder.start();
    }

    public void stopRecording() {
        recorder.stop();
        recorder.release();
        addRecordingToMediaLibrary();
        return;
    }

    protected void addRecordingToMediaLibrary() {
        Log.v("HomeReceiver3", "HomeReceiver");
        ContentValues values = new ContentValues(4);
        long current = System.currentTimeMillis();
        values.put(MediaStore.Audio.Media.TITLE, "audio" + audiofile.getName());
        values.put(MediaStore.Audio.Media.DATE_ADDED, (int) (current / 1000));
        values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/3gpp");
        values.put(MediaStore.Audio.Media.DATA, audiofile.getAbsolutePath());
        //creating content resolver and storing it in the external content uri
        Log.v("HomeReceiver1", "HomeReceiver");
        ContentResolver contentResolver = getContentResolver();
        Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Uri newUri = contentResolver.insert(base, values);
        Log.v("HomeReceiver2", "HomeReceiver");
        //sending broadcast message to scan the media file so that it can be available
        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, newUri));
        Toast.makeText(this, "Added File " + newUri, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onReadyForSpeech(Bundle params) {

    }

    @Override
    public void onBeginningOfSpeech() {
        listenerVoice.setImageDrawable(mContext.getDrawable(R.drawable.music_player));
    }

    @Override
    public void onRmsChanged(float rmsdB) {

    }

    @Override
    public void onBufferReceived(byte[] buffer) {

    }

    @Override
    public void onEndOfSpeech() {
        listenerVoice.setEnabled(true);
        mVoiceListener = false;
        speech.stopListening();
        listenerVoice.setImageDrawable(mContext.getDrawable(R.drawable.muted_speech_listener));
    }

    @Override
    public void onError(int error) {
        String errorMessage = getErrorText(error);
        listenerVoice.setEnabled(true);
    }

    @Override
    public void onResults(Bundle results) {

    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        Log.d("Log", "onPartialResults");
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String text = "";
        text = matches.get(0);
        mVoiceText.setText(text);
    }

    @Override
    public void onEvent(int eventType, Bundle params) {

    }

    public static class HomeReceiver extends BroadcastReceiver {
        public HomeReceiver() {
            super();
            Log.v("HomeReceiver", "HomeReceiver");
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.v("HomeReceiver", "onRecive  action : " + intent.getAction());
        }
    }

    public void sendSMS(String phoneNo, String msg) {
        Log.e(TAG, "hideProgressBar " + phoneNo);
        try {
            if (ActivityCompat.checkSelfPermission(this, SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                try {
                    SmsManager smsMgrVar = SmsManager.getDefault();
                    smsMgrVar.sendTextMessage(phoneNo, null, msg, null, null);
                    Toast.makeText(getApplicationContext(), "Message Sent", Toast.LENGTH_LONG).show();
                } catch (Exception ErrVar) {
                    Toast.makeText(getApplicationContext(), ErrVar.getMessage().toString(), Toast.LENGTH_LONG).show();
                    ErrVar.printStackTrace();
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{SEND_SMS}, 10);
                }
            }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), ex.getMessage().toString(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private ArrayList<Object> getContactList() {
        ArrayList<Object> temp = new ArrayList<>();
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur != null && cur.moveToNext()) {
                String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                if (cur.getInt(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        // Log.e(TAG, "Name: " + name);
                        //Log.e(TAG, "Phone Number: " + phoneNo);
                        mPhoneNumberList.add(phoneNo);
                        String detail = name + "(" + phoneNo + ")";
                        temp.add(detail);
                    }
                    pCur.close();
                }
            }
        }
        if (cur != null) {
            cur.close();
        }
        return temp;
    }

    private void smsSendDisplay(final ArrayList<Object> temps) {
        hideProgressBar();
        final Dialog smsSendData = new Dialog(mContext);
        smsSendData.setContentView(R.layout.sms_send_view);
        final LinearLayout mainLayout = (LinearLayout) findViewById(R.id.mainLayout);
        mainLayout.setVisibility(View.GONE);
        final EditText textData = (EditText) smsSendData.findViewById(R.id.edit_sms);
        final Button sendSms = (Button) smsSendData.findViewById(R.id.btn_send);
        final Button closeSms = (Button) smsSendData.findViewById(R.id.btn_close);
        final EditText mSearchView = (EditText) smsSendData.findViewById(R.id.search_edit_text);
        final RecyclerView mRecyclerSearchView = (RecyclerView) smsSendData.findViewById(R.id.recycler_search_view);
        mRecyclerSearchView.addItemDecoration(new DividerItemDecoration(MainActivity.this, DividerItemDecoration.VERTICAL));
        final RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this);
        mRecyclerSearchView.setLayoutManager(mLayoutManager);
        mRecyclerSearchView.setItemAnimator(new DefaultItemAnimator());
        mSearchViewAdapter = new SearchViewAdapter(MainActivity.this, temps, new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position, final List<Object> list) {
                String data = (String) list.get(position);
                mRecyclerSearchView.setVisibility(View.GONE);
                int latestPosition = temps.indexOf(data);
                mPhoneNumber = mPhoneNumberList.get(latestPosition);
                mSearchView.setText("" + data);
            }

            @Override
            public boolean onItemLongClick(View v, int position, List<Object> list) {
                return false;
            }
        });
        mRecyclerSearchView.setAdapter(mSearchViewAdapter);
        mSearchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mSearchViewAdapter.getFilter().filter(s);
            }
        });
        sendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TAG, "Profile....start send");
                String sms = textData.getText().toString();
                Log.e(TAG, "Profile....sms send" + sms + mPhoneNumber);
                sendSMS(mPhoneNumber, sms);
                smsSendData.dismiss();
                mainLayout.setVisibility(View.VISIBLE);
            }
        });
        closeSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TAG, "Profile....stop send");
                smsSendData.dismiss();
                mainLayout.setVisibility(View.VISIBLE);
            }
        });
        smsSendData.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        smsSendData.show();
        smsSendData.setCancelable(false);
        Log.v(TAG, "search completed");
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        mPhoneNumber = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), "Selected: " + mPhoneNumber, Toast.LENGTH_LONG).show();
    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{CAMERA, READ_CONTACTS, READ_PHONE_STATE, READ_EXTERNAL_STORAGE,
                ACCESS_COARSE_LOCATION, RECORD_AUDIO, SEND_SMS,CALL_PHONE}, RequestPermissionCode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case RequestPermissionCode:
                if (grantResults.length > 0) {
                    boolean CameraPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean ReadContactsPermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean ReadPhoneStatePermission = grantResults[2] == PackageManager.PERMISSION_GRANTED;
                    boolean smsPermission = grantResults[3] == PackageManager.PERMISSION_GRANTED;
                    boolean locationContactsPermission = grantResults[4] == PackageManager.PERMISSION_GRANTED;
                    boolean TelephoneStatePermission = grantResults[5] == PackageManager.PERMISSION_GRANTED;
                    boolean microPhoneStatePermission = grantResults[6] == PackageManager.PERMISSION_GRANTED;
                    boolean phoneCallPermission = grantResults[7] == PackageManager.PERMISSION_GRANTED;
                    if (CameraPermission && ReadContactsPermission && ReadPhoneStatePermission
                            && smsPermission && locationContactsPermission && TelephoneStatePermission
                            && microPhoneStatePermission && phoneCallPermission) {
                        Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Permission Denied", Toast.LENGTH_LONG).show();
                    }
                }

                break;
        }
    }

    public boolean checkPermission() {
        int FirstPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), CAMERA);
        int SecondPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), READ_CONTACTS);
        int ThirdPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), READ_PHONE_STATE);
        int FourPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        int FifthPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), ACCESS_COARSE_LOCATION);
        int SixPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), RECORD_AUDIO);
        int SevenPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), SEND_SMS);
        int EightPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), CALL_PHONE);

        return FirstPermissionResult == PackageManager.PERMISSION_GRANTED &&
                SecondPermissionResult == PackageManager.PERMISSION_GRANTED &&
                ThirdPermissionResult == PackageManager.PERMISSION_GRANTED &&
                FourPermissionResult == PackageManager.PERMISSION_GRANTED &&
                FifthPermissionResult == PackageManager.PERMISSION_GRANTED &&
                SixPermissionResult == PackageManager.PERMISSION_GRANTED &&
                SevenPermissionResult == PackageManager.PERMISSION_GRANTED &&
                EightPermissionResult == PackageManager.PERMISSION_GRANTED;
    }

    private void phoneDetails() {
        final Runtime runtime = Runtime.getRuntime();
        final long usedMemInMB=(runtime.totalMemory() - runtime.freeMemory()) / 1048576L;
        final long maxHeapSizeInMB=runtime.maxMemory() / 1048576L;
        final long availHeapSizeInMB = maxHeapSizeInMB - usedMemInMB;
        String details = "\tVERSION.RELEASE : " + Build.VERSION.RELEASE
                + "\t\nVERSION.INCREMENTAL : " + Build.VERSION.INCREMENTAL
                + "\t\nVERSION.SDK.NUMBER : " + Build.VERSION.SDK_INT
                + "\t\nBOARD : " + Build.BOARD
                + "\t\nBOOTLOADER : " + Build.BOOTLOADER
                + "\t\nBRAND : " + Build.BRAND
                + "\t\nCPU_ABI : " + Build.CPU_ABI
                + "\t\nCPU_ABI2 : " + Build.CPU_ABI2
                + "\t\nDISPLAY : " + Build.DISPLAY
                + "\t\nFINGERPRINT : " + Build.FINGERPRINT
                + "\t\nHARDWARE : " + Build.HARDWARE
                + "\t\nHOST : " + Build.HOST
                + "\t\nID : " + Build.ID
                + "\t\nMANUFACTURER : " + Build.MANUFACTURER
                + "\t\nMODEL : " + Build.MODEL
                + "\t\nPRODUCT : " + Build.PRODUCT
                + "\t\nSERIAL : " + Build.SERIAL
                + "\t\nTAGS : " + Build.TAGS
                + "\t\nTIME : " + Build.TIME
                + "\t\nTYPE : " + Build.TYPE
                + "\t\nUNKNOWN : " + Build.UNKNOWN
                + "\t\nUSER : " + Build.USER
                + "\t\nAvailable Heap size : " +availHeapSizeInMB
                + "\t\nTotal Heap size : " +maxHeapSizeInMB;

        mDisplayPopup = new Dialog(MainActivity.this);
        mDisplayPopup.setContentView(R.layout.phone_status_popup);
        final TextView text_dialog = (TextView) mDisplayPopup.findViewById(R.id.text_dialog);
        text_dialog.setText(details);
        text_dialog.setMovementMethod(new ScrollingMovementMethod());
        Button cancel = (Button) mDisplayPopup.findViewById(R.id.btn_cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDisplayPopup.dismiss();
                mDisplayPopup = null;
            }
        });
        mDisplayPopup.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mDisplayPopup.show();
    }

    private void speechToText() {
        mDisplayPopup = new Dialog(MainActivity.this);
        mDisplayPopup.setContentView(R.layout.speech_to_text_popup);
        mVoiceText = (TextView) mDisplayPopup.findViewById(R.id.text_dialog);
        mVoiceText.setMovementMethod(new ScrollingMovementMethod());
        listenerVoice = (ImageView) mDisplayPopup.findViewById(R.id.btn_voice_listener);
        Button cancel = (Button) mDisplayPopup.findViewById(R.id.btn_cancel);
        speech = SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(this);
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, this.getPackageName());
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 5000);
        recognizerIntent.putExtra("android.speech.extra.DICTATION_MODE", true);
        listenerVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mVoiceText.setText("");
                if(mVoiceListener) {
                    listenerVoice.setEnabled(true);
                    mVoiceListener = false;
                    speech.stopListening();
                    listenerVoice.setImageDrawable(mContext.getDrawable(R.drawable.muted_speech_listener));
                } else {
                    listenerVoice.setEnabled(false);
                    listenerVoice.setImageDrawable(mContext.getDrawable(R.drawable.speech_listener));
                    mVoiceListener = true;
                    speech.startListening(recognizerIntent);
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (speech != null) {
                    speech.destroy();
                    Log.d("Log", "destroy");
                }
                listenerVoice.setEnabled(true);
                mVoiceListener = false;
                mDisplayPopup.dismiss();
                mDisplayPopup = null;
            }
        });
        mDisplayPopup.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mDisplayPopup.show();
    }

    public static String getErrorText(int errorCode) {
        String message;
        switch (errorCode) {
            case SpeechRecognizer.ERROR_AUDIO:
                message = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                message = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                message = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                message = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                message = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                message = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                message = "RecognitionService busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                message = "error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                message = "No speech input";
                break;
            default:
                message = "Didn't understand, please try again.";
                break;
        }
        return message;
    }

}