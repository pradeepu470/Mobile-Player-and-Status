package com.pradeep.videoplayercollection;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Parcel;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.LinearLayout;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.media.AudioManager;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import android.widget.VideoView;

import com.pradeep.videoplayercollection.dbase.UserDatabaseAccess;

import java.io.IOException;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;

public class RecordPlaybackActivity extends AppCompatActivity
        implements MediaPlayer.OnPreparedListener {
    String mPath;
    String mNextPath;
    private Context mContext;
    private static final String TAG = "RecordPlaybackActivity";
    private int mCurrentPosition;
    private SeekBar mSeekBar;
    private TextView mStartTime;
    private TextView mEndTime;
    private Runnable mRunnable;
    private LinearLayout mSeekBarLinearLayout;
    private Object mSeekBarHideToken = new Object();
    private Handler mHandler = new Handler();
    private IntentFilter mIntentFilter;
    private RecordedPlaybackReceiver mDvbBroadcastReceiver;
    private RecyclerView recorded_content_list;
    private ArrayList<Object> mRecordedEvent;
    private int playerIndex = 0;
    private RecordedAdapter mRecordListAdapter;
    private VideoView mVideoView;
    private UserDatabaseAccess mDVBUserDatabase;
    private boolean touched = false;
    private Activity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.activity_record_playback);
        mActivity = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        mVideoView = (VideoView) findViewById(R.id.video_view);
        mContext = this.getApplicationContext();
        mPath = (this.getIntent()).getStringExtra("uri");
        mCurrentPosition = this.getIntent().getIntExtra("view_position", 0);
        mSeekBar = findViewById(R.id.seek_bar);
        mSeekBarLinearLayout = findViewById(R.id.record_seek_data);
        mStartTime = findViewById(R.id.start_time);
        mEndTime = findViewById(R.id.end_time);
        recorded_content_list = (RecyclerView) findViewById(R.id.my_recycler_view);
        Log.v(TAG, "Record file path : " + mPath);
        mRecordedEvent = new ArrayList<>();
        mIntentFilter = new IntentFilter();
        mDvbBroadcastReceiver = new RecordedPlaybackReceiver();
        mContext.registerReceiver(mDvbBroadcastReceiver, mIntentFilter);
        getAllRecordedVideo();
        displayRecordedList();
        addPlayerListners();
        mPath = "" + mRecordedEvent.get(0);
        mDVBUserDatabase = UserDatabaseAccess.getInstance(this);
        addClickListeners();
    }

    private int getLastWatchPosition() {
        int position = 0;
        if (mDVBUserDatabase != null) {
            Parcel request = Parcel.obtain();
            request.setDataPosition(0);
            request.writeString(mPath);
            request.setDataPosition(0);
            CommonFile.DB_Status status = mDVBUserDatabase.fetchUserData(request, CommonFile.kActionCheckRecord);
            if (status == CommonFile.DB_Status.STATUS_OK) {
                position = request.readInt();
            } else {

            }
        }
        mCurrentPosition = position;
        return position;
    }

    private void getUpdateWatchPosition() {
        if (mDVBUserDatabase != null) {
            Parcel request = Parcel.obtain();
            request.setDataPosition(0);
            request.writeString(mPath);
            request.writeInt(mCurrentPosition);
            request.setDataPosition(0);
            CommonFile.DB_Status status = mDVBUserDatabase.fetchUserData(request, CommonFile.kActionUpdateRecordView);
            if (status == CommonFile.DB_Status.STATUS_OK) {

            } else {

            }
        }
        return;
    }

    private void resumeRecordPlayback() {
        final Dialog recordResume = new Dialog(RecordPlaybackActivity.this);
        recordResume.setContentView(R.layout.record_resume_popup);
        final TextView text_dialog = (TextView) recordResume.findViewById(R.id.text_dialog);
        text_dialog.setText(R.string.record_title);
        final Button resume = (Button) recordResume.findViewById(R.id.btn_resume);
        resume.setText("Resume");
        resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mVideoView.setVideoPath(mPath);
                mVideoView.requestFocus();
                mVideoView.seekTo(mCurrentPosition);
                mVideoView.start();
                seekBarClick();
                recordResume.dismiss();
            }
        });
        Button restart = (Button) recordResume.findViewById(R.id.btn_restart);
        restart.setText("Restart");
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentPosition = 0;
                mVideoView.setVideoPath(mPath);
                mVideoView.requestFocus();
                mVideoView.start();
                seekBarClick();
                recordResume.dismiss();
            }
        });
        recordResume.setCancelable(false);
        recordResume.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        recordResume.show();
    }

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        Log.i(TAG, "onPrepared");
        if (!mediaPlayer.isPlaying()) {
            initializeSeekBar();
            mediaPlayer.seekTo(mCurrentPosition);
            mediaPlayer.start();
            mHandler.removeCallbacksAndMessages(mSeekBarHideToken);
            Log.v(TAG, "MotionEvent.on prepared");
            updateSeekBarData();
        }
    }


    private void addClickListeners() {
        Log.v(TAG, "addClickListeners");
        if (getLastWatchPosition() > 0) {
            resumeRecordPlayback();
            return;
        }
        mVideoView.setVideoPath(mPath);
        mVideoView.requestFocus();
        mVideoView.start();
        seekBarClick();
        mSeekBarLinearLayout.setOnTouchListener(screenTouch);
        recorded_content_list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                updateSeekBarData();
            }

        });
    }

    private void seekBarClick() {
        Log.e(TAG, "seekBarClick");
        ImageButton play = (ImageButton) findViewById(R.id.btn_play_pause);
        ImageButton next = (ImageButton) findViewById(R.id.btn_next);
        ImageButton previous = (ImageButton) findViewById(R.id.btn_previous);
        final ImageButton muteButton = (ImageButton) findViewById(R.id.btn_mute);
        final ImageButton zoomButton = (ImageButton) findViewById(R.id.btn_zoom) ;
        zoomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RelativeLayout view = (RelativeLayout) findViewById(R.id.activity_record_playback);
                if (mActivity.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                } else {
                    mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                }
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "play video");
                if (mVideoView.isPlaying()) {
                    mVideoView.pause();
                } else {
                    mVideoView.start();
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "Record file path : " + mPath);
                Log.v(TAG, "play video");
                if (playerIndex < mRecordedEvent.size() - 1) {
                    playerIndex++;
                } else {
                    playerIndex = 0;
                }
                mNextPath = "" + mRecordedEvent.get(playerIndex);
                nextPlayer();
            }
        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TAG, "play video");
                if (playerIndex > 0) {
                    playerIndex--;
                } else {
                    playerIndex = mRecordedEvent.size();
                }
                mNextPath = "" + mRecordedEvent.get(playerIndex);
                nextPlayer();
            }
        });

        muteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v(TAG, "play video");
                AudioManager audioManager = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, 0);
                boolean mute = audioManager.isStreamMute(AudioManager.STREAM_MUSIC);
                if (mute == true) {
                    muteButton.setImageResource(R.drawable.volume);
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
                } else {
                    muteButton.setImageResource(R.drawable.mute);
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0);
                }
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
        mCurrentPosition = (int) mVideoView.getCurrentPosition() / 1000;
        int totalPosition = (int) mVideoView.getDuration() / 1000;
        if (mCurrentPosition >= totalPosition) {
            mCurrentPosition = 0;
        }
        mCurrentPosition *= 1000;
        getUpdateWatchPosition();
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        Log.i(TAG, "updateWatchPosition" + mCurrentPosition);
        mContext.unregisterReceiver(mDvbBroadcastReceiver);
        super.onDestroy();
        Log.i(TAG, "onDestroy");
        mVideoView.stopPlayback();
    }

    @Override
    public void onBackPressed() {
        Log.i(TAG, "onBackPressed");
        super.onBackPressed();
        Intent i = new Intent(RecordPlaybackActivity.this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
        startActivity(i);
        finish();
    }

    public void addPlayerListners() {
        Log.i(TAG, "addPlayerListners");
        mVideoView.setOnPreparedListener(this);
        mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.i(TAG, "onError, what :" + what + ", extra :" + extra);
                return false;
            }
        });

        mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Log.e(TAG, "onCompletion");
                mCurrentPosition = (int) mVideoView.getCurrentPosition() / 1000;
                int totalPosition = (int) mVideoView.getDuration() / 1000;
                if (mCurrentPosition >= totalPosition) {
                    mCurrentPosition = 0;
                }
                mCurrentPosition *= 1000;
                getUpdateWatchPosition();
                if (playerIndex < mRecordedEvent.size() - 1) {
                    playerIndex++;
                } else {
                    playerIndex = 0;
                }
                mNextPath = "" + mRecordedEvent.get(playerIndex);
                nextPlayer();
            }
        });

        mVideoView.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                Log.i(TAG, "received info : " + what + " : " + extra);
                return true;
            }
        });
        RelativeLayout viewData = (RelativeLayout)findViewById(R.id.activity_record_playback);
        viewData.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (mSeekBarLinearLayout.getVisibility() == View.VISIBLE) {
                        mHandler.removeCallbacksAndMessages(mSeekBarHideToken);
                        mSeekBarLinearLayout.setVisibility(View.GONE);
                        return true;
                    }
                    updateSeekBarData();
                }
                return true;
            }
        });
    }

    private void seekBarPosition() {
        long totalTime = mVideoView.getDuration(); // In milliseconds
        long currentTime = mVideoView.getCurrentPosition();
        int currentTimeHours = (int) (currentTime / (60 * 60 * 1000));
        int currentTimeMinutes = (int) (currentTime / (60 * 1000));
        int currentTimeSeconds = (int) ((currentTime / 1000) % 60);
        int totalTimeHours = (int) (totalTime / (60 * 60 * 1000));
        int totalTimeMinutes = (int) (totalTime / (60 * 1000));
        int totalTimeSeconds = (int) ((totalTime / 1000) % 60);
        if (currentTimeHours == 0) {
            mStartTime.setText("" + currentTimeMinutes + " :" + currentTimeSeconds);
        } else {
            mStartTime.setText("" + currentTimeHours + ":" + currentTimeMinutes + " :" + currentTimeSeconds);
        }
        if (totalTimeHours == 0) {
            mEndTime.setText("" + totalTimeMinutes + " :" + totalTimeSeconds);
        } else {
            mEndTime.setText("" + totalTimeHours + ":" + totalTimeMinutes + " :" + totalTimeSeconds);
        }
    }

    private void initializeSeekBar() {
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (mVideoView != null && b) {
                    Log.e(TAG, "seek to data" + i * 10);
                    mVideoView.seekTo(i * 10);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.v(TAG, "onStartTrackingTouch");
                mHandler.removeCallbacksAndMessages(mSeekBarHideToken);
                mSeekBarLinearLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.v(TAG, "onStopTrackingTouch");
                updateSeekBarData();
            }
        });
        mSeekBar.setMax(mVideoView.getDuration() / 10);
        final Handler handler = new Handler();
        mRunnable = new Runnable() {
            @Override
            public void run() {
                if (mVideoView != null) {
                    int currentPosition = mVideoView.getCurrentPosition() / 10; // In seconds
                    mSeekBar.setProgress(currentPosition);
                    seekBarPosition();
                }
                handler.postDelayed(mRunnable, 10);
            }
        };
        handler.postDelayed(mRunnable, 10);
    }

    private void updateSeekBarData() {
        Log.v(TAG, "updateSeekBarData");
        mHandler.removeCallbacksAndMessages(mSeekBarHideToken);
        mSeekBarLinearLayout.setVisibility(View.VISIBLE);
        mHandler.postAtTime(new Runnable() {
            @Override
            public void run() {
                Log.v(TAG, "updateSeekBarData gone");
                mSeekBarLinearLayout.setVisibility(View.GONE);
            }
        }, mSeekBarHideToken, SystemClock.uptimeMillis() + 5000);
    }

    private void getAllRecordedVideo() {
        HashSet<String> videoItemHashSet = new HashSet<>();
        String[] projection = {MediaStore.Video.VideoColumns.DATA, MediaStore.Video.Media.DISPLAY_NAME};
        Cursor cursor = RecordPlaybackActivity.this.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, null);
        try {
            cursor.moveToFirst();
            do {
                videoItemHashSet.add((cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA))));
            } while (cursor.moveToNext());
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        ArrayList<String> downloadedList = new ArrayList<>(videoItemHashSet);
        mRecordedEvent.addAll(downloadedList);
    }

    private void displayRecordedList() {
        mRecordListAdapter = new RecordedAdapter(RecordPlaybackActivity.this, mRecordedEvent, new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, final int position, final List<Object> recordedEvent) {
                try {
                    playerIndex = position;
                    mNextPath = "" + mRecordedEvent.get(playerIndex);
                    mCurrentPosition = 0;
                    nextPlayer();
                } catch (IndexOutOfBoundsException ex) {
                    Log.w(TAG, "No such Item exists");
                    return;
                }
            }

            @Override
            public boolean onItemLongClick(View v, final int position, final List<Object> recordedEvent) {
                try {
                    Log.v(TAG, "record content onLongClicked");
                    mNextPath = "" + mRecordedEvent.get(playerIndex);
                    deleteFile(mNextPath);
                    mRecordListAdapter.notifyDataSetChanged();
                } catch (IndexOutOfBoundsException ex) {
                    Log.w(TAG, "No such Item exists");
                }
                return true;
            }
        });
        recorded_content_list.setAdapter(mRecordListAdapter);

    }

    private class RecordedPlaybackReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("data")) {

            }
        }
    }

    private void nextPlayer() {
        mCurrentPosition = (int) mVideoView.getCurrentPosition() / 1000;
        int totalPosition = (int) mVideoView.getDuration() / 1000;
        if (mCurrentPosition >= totalPosition) {
            mCurrentPosition = 0;
        }
        mCurrentPosition *= 1000;
        getUpdateWatchPosition();
        mPath = mNextPath;
        if (getLastWatchPosition() > 0) {
            mVideoView.stopPlayback();
            resumeRecordPlayback();
            return;
        }
        mVideoView.setVideoPath(mPath);
        mVideoView.requestFocus();
        mVideoView.start();
        seekBarClick();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.activity_record_playback);
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setContentView(R.layout.activity_record_playback);
        }
    }
    private View.OnTouchListener screenTouch = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View arg0, MotionEvent arg1) {
            switch (arg1.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    int button1IsVisible = mSeekBarLinearLayout.getVisibility();
                    touched = true;
                    if (touched == true) {
                        if (button1IsVisible == View.GONE) {
                            updateSeekBarData();
                            touched = false;
                        } else {
                            mSeekBarLinearLayout.setVisibility(View.GONE);
                            touched = false;
                        }
                    }
                    break;

            }
            return true;
        }
    };

}

