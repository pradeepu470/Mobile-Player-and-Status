package com.pradeep.videoplayercollection;

import android.content.Context;
import android.graphics.Color;
import android.os.Parcel;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import android.content.Intent;

import  com.pradeep.videoplayercollection.dbase.UserDatabaseAccess;

import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistrationActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private static final String TAG = "RegistrationActivity";
    private SessionManager mSession;
    private Spinner mFirstQuestionSpiner;
    private ArrayAdapter<String> mFirstQuestionAdapter;
    private Spinner mSecondQuestionSpiner;
    private ArrayAdapter<String> mSecondQuestionAdapter;
    private ArrayList<String> mQuestionList;
    private ArrayList<String> mQuestionTempList = new ArrayList<>();

    private EditText mInputName, mInputUserName, mInputEmail, mInputPassword, mInputConfrmPassword, mInputAnswer1, mInputAnswer2;
    private Button mRegisterButton;
    private String mQuestion1, mQuestion2;
    private int mUserId;
    private UserDatabaseAccess mDVBUserDatabase = null;
    private TextView mLoginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        mSession = SessionManager.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        final View decorView = getWindow().getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                hideSystemUI();


            }
        });


        mDVBUserDatabase = UserDatabaseAccess.getInstance(this);
        mInputName = (EditText) findViewById(R.id.input_name);
        mInputUserName = (EditText) findViewById(R.id.username);
        mInputEmail = (EditText) findViewById(R.id.email);
        mInputPassword = (EditText) findViewById(R.id.password);
        mInputConfrmPassword = (EditText) findViewById(R.id.confirm_pass);
        mInputAnswer1 = (EditText) findViewById(R.id.input_ans1);
        mInputAnswer2 = (EditText) findViewById(R.id.input_ans2);
        mRegisterButton = (Button) findViewById(R.id.registerButton);
        mQuestionList = new ArrayList<String>();
        mQuestionList.add("Select an item...");
        mQuestionList.add("What is your favroite hang out place");
        mQuestionList.add("Which is your favorite sports");
        mQuestionList.add("Name of your first pet");
        mQuestionList.add("Anniversary date of your parents");
        mQuestionList.add("Your childhood best friends name");
        mQuestionTempList.addAll(mQuestionList);
        mLoginButton =(TextView)findViewById(R.id.login);

        mFirstQuestionSpiner = (Spinner) findViewById(R.id.question1);
        mFirstQuestionAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mQuestionTempList) {
            @Override
            public boolean isEnabled(int position) {
                if (position == 0) {
                    // Disable the first item from Spinner
                    // First item will be use for hint
                    return false;
                } else {
                    return true;
                }
            }
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if (position == 0) {
                    // Set the hint text color gray
                    tv.setTextColor(Color.GRAY);
                } else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        mFirstQuestionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mFirstQuestionSpiner.setAdapter(mFirstQuestionAdapter);
        mFirstQuestionSpiner.setOnItemSelectedListener(this);

        mSecondQuestionSpiner = (Spinner) findViewById(R.id.question2);
        mSecondQuestionAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mQuestionTempList) {
            @Override
            public boolean isEnabled(int position) {
                if (position == 0) {
                    // Disable the first item from Spinner
                    // First item will be use for hint
                    return false;
                } else {
                    return true;
                }
            }
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if (position == 0) {
                    // Set the hint text color gray
                    tv.setTextColor(Color.GRAY);
                } else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        mSecondQuestionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSecondQuestionSpiner.setAdapter(mSecondQuestionAdapter);
        mSecondQuestionSpiner.setOnItemSelectedListener(this);

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissKeyboard();
                Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        mRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateFormTwo()) {
                    String newUser = mInputUserName.getText().toString();
                    String newPassword = mInputPassword.getText().toString();
                    String newEmail = mInputEmail.getText().toString();
                    String name = mInputName.getText().toString();
                    String answer1 = mInputAnswer1.getText().toString();
                    String answer2 = mInputAnswer2.getText().toString();
                    String mac_val = getMAC();
                    if (mSession.isRegister()) {
                        if (mDVBUserDatabase != null) {
                            Parcel info = Parcel.obtain();
                            info.setDataPosition(0);
                            info.writeString("verifyUserName");
                            info.writeString(newUser);
                            CommonFile.DB_Status status = mDVBUserDatabase.fetchUserData(info, CommonFile.kActionVerfyUser);
                            if (status == CommonFile.DB_Status.STATUS_OK) {
                                Log.e(TAG, "User name is already exists" + status);    
                                Toast.makeText(getApplicationContext(),"User name already exists :",Toast.LENGTH_SHORT).show();
                                return;
                            } else {
                                Log.e(TAG, "User name doesn't exists : " + status);
                            }
                        }
                       
                        if (mDVBUserDatabase != null) {
                            Parcel info = Parcel.obtain();
                            info.setDataPosition(0);
                            info.writeString("verifymail");
                            info.writeString(newEmail);
                            CommonFile.DB_Status status = mDVBUserDatabase.fetchUserData(info, CommonFile.kActionVerfyUser);
                            if (status == CommonFile.DB_Status.STATUS_OK) {
                                Log.e(TAG, "Email id is already registered" + status);
                                Toast.makeText(getApplicationContext(),"Email already registered :",Toast.LENGTH_SHORT).show(); 
                                return;
                            } else {
                                Log.e(TAG, "Email doesn't exists : " + status);
                            }
                        }
                    }
                    Parcel info = Parcel.obtain();
                    info.setDataPosition(0);
                    info.writeString(name);
                    info.writeString(newUser);
                    info.writeString(newPassword);
                    info.writeString(newEmail);
                    info.writeString(mac_val);
                    info.writeString(mQuestion1);
                    info.writeString(answer1);
                    info.writeString(mQuestion2);
                    info.writeString(answer2);
                    CommonFile.DB_Status status = mDVBUserDatabase.fetchUserData(info, CommonFile.kActionRegisterUser);
                    if (status != CommonFile.DB_Status.STATUS_OK) {
                        Log.e(TAG, "User registration failed with err : " + status);
                        Toast.makeText(getApplicationContext(), "Your Registration is not Done Sucessfully", Toast.LENGTH_SHORT).show();

                    } else {
                        info.setDataPosition(0);
                        mUserId = info.readInt();
                        Log.v(TAG, "User registration successful, Usreid : " + mUserId);
                        Toast.makeText(getApplicationContext(),"Your Registration Done Sucessfully",Toast.LENGTH_SHORT).show();
                        mSession.setRegister(true, mUserId);
                        Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();

                    }
                }
            }
        });

    }


    public static void resetForm(ViewGroup group) {
        for (int i = 0, count = group.getChildCount(); i < count; ++i) {
            View view = group.getChildAt(i);
            if (view instanceof EditText) {
                ((EditText) view).getText().clear();
            }

            if (view instanceof Spinner) {
                ((Spinner) view).setSelection(0);
            }

            if (view instanceof ViewGroup && (((ViewGroup) view).getChildCount() > 0))
                resetForm((ViewGroup) view);
        }
    }

    private String getMAC() {

        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;

                byte[] macBytes = nif.getHardwareAddress();
                Log.v(TAG, "MAC: " + macBytes);

                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(String.format("%02X", b));
                }

/*                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }*/
                Log.v(TAG, "MAC : " + res1.toString());
                return res1.toString();
            }
        } catch (Exception ex) {
            Log.w(TAG, "Exception occured");
        }
        return null;

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        parent.getItemAtPosition(position);
        String item = parent.getItemAtPosition(position).toString();
        switch (parent.getId()) {
            case R.id.question1:
                if (position > 0) {
                    mQuestion1 = null;
                    mQuestion1 = item;
                    //Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_SHORT).show();
                    mQuestionTempList.clear();
                    mQuestionTempList.addAll(mQuestionList);
                    mQuestionTempList.remove(item);
                    mSecondQuestionAdapter.notifyDataSetChanged();
                }
                break;

            case R.id.question2:
                if (position > 0) {
                    mQuestion2 = null;
                    mQuestion2 = item;
                    mQuestionTempList.clear();
                    mQuestionTempList.addAll(mQuestionList);
                    mQuestionTempList.remove(item);
                    mFirstQuestionAdapter.notifyDataSetChanged();
                }
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public boolean validateFormOne() {

        boolean valid = true;

        String name = mInputName.getText().toString();
        String username = mInputUserName.getText().toString();
        String email = mInputEmail.getText().toString();
        String password = mInputPassword.getText().toString();
        String reEnterPassword = mInputConfrmPassword.getText().toString();

        if (name.isEmpty() || !validateName(name)) {
            mInputName.setError("Enter at least 3 characters");
            valid = false;
        } else {
            mInputName.setError(null);
        }

        if (username.isEmpty() || !validateUserName(username)) {
            mInputUserName.setError("Enter at least 3 characters");
            valid = false;
        } else {
            mInputUserName.setError(null);
        }


        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mInputEmail.setError("Enter a valid email address");
            valid = false;
        } else {
            mInputEmail.setError(null);
        }


        if (password.isEmpty() || !validatePassword(password)) {
            mInputPassword.setError("Password must between 8 and 15 alphanumeric characters and Atleast 1 capital letter, 1 number, 1 special character and SHOULD NOT start with a special character ");
            valid = false;
        } else {
            mInputPassword.setError(null);
        }

        if (reEnterPassword.isEmpty() || !(reEnterPassword.equals(password))) {
            mInputConfrmPassword.setError("Password Do not match");
            valid = false;
        } else {
            mInputConfrmPassword.setError(null);
        }

        return valid;

    }

    public boolean validateFormTwo() {
        boolean valid = true;

        String answer1 = mInputAnswer1.getText().toString();
        String answer2 = mInputAnswer2.getText().toString();


        if (answer1.isEmpty() || !validateAnswer(answer1)) {
            mInputAnswer1.setError("Enter at least 3 characters");
            valid = false;
        } else {
            mInputAnswer1.setError(null);
        }
        if (answer2.isEmpty() || !validateAnswer(answer1)) {
            mInputAnswer2.setError("Enter at least 3 characters");
            valid = false;
        } else {
            mInputAnswer2.setError(null);
        }
        return valid;
    }

    /**
     *
     * @param password
     * @return
     */
    public boolean validatePassword(final String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$&_])[A-Za-z\\d][A-Za-z\\d@#$&_]{7,19}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }

    /**
     *
     * @param username
     * @return
     */
    private boolean validateUserName(final String username) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^[A-Za-z0-9@#$&_.-]{3,19}+$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(username);
        return matcher.matches();

    }

    /**
     *
     * @param name
     * @return
     */
    private boolean validateName(final String name) {
        Pattern pattern;
        Matcher matcher;
        final String NAME_PATTERN = "^[A-Za-z ]{3,19}+$";
        pattern = Pattern.compile(NAME_PATTERN);
        matcher = pattern.matcher(name);
        return matcher.matches();

    }

    /**
     *
     * @param answer
     * @return
     */
    private boolean validateAnswer(final String answer) {
        Pattern pattern;
        Matcher matcher;
        final String ANSWER_PATTERN = "^(?:[a-zA-Z0-9 ]{3,19}+)?$";
        pattern = Pattern.compile(ANSWER_PATTERN);
        matcher = pattern.matcher(answer);
        return matcher.matches();

    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE);

        }
    }

    private void hideSystemUI() {

    View decorView = getWindow().getDecorView();
    decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION 
            | View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
            | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    @Override
    public void onBackPressed() {
        if (mSession.isRegister() && mSession.isPinGenerated()) {
            super.onBackPressed(); 
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public void dismissKeyboard() {
        InputMethodManager inputManager = (InputMethodManager)
                getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }

}
