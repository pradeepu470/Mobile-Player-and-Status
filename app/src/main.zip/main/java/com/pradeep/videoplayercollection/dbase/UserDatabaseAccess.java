package com.pradeep.videoplayercollection.dbase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Parcel;
import android.util.Log;
import com.pradeep.videoplayercollection.CommonFile;
import com.pradeep.videoplayercollection.dbase.DatabaseHandler;

import java.io.File;

public class UserDatabaseAccess {
    String TAG = "UserDatabaseAccess";
    private static UserDatabaseAccess sInstance = null;
    private DatabaseHandler mUserData = null;
    private Context mcontext = null;
    private UserDatabaseAccess(Context context){
        mcontext = context;
        mUserData = new DatabaseHandler(context);
    }

    public static UserDatabaseAccess getInstance(Context context) {
        synchronized (UserDatabaseAccess.class) {
            if (sInstance == null) {
                sInstance = new UserDatabaseAccess(context);
            }
        }
        return sInstance;
    }

    public CommonFile.DB_Status fetchUserData(Parcel info, int type) {
        Log.v(TAG, "fetch User Data");
        if (mUserData == null) {
            Log.e(TAG, "Database connection is lost. Unable to fetch requested data");
            info = null;
            return CommonFile.DB_Status.STATUS_ERROR;
        }
        return mUserData.fetchUserDataBase(type, info);
    }
}

